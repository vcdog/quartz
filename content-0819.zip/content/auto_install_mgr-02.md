# Auto install MGR ReadMe.


# 架构图1：

![架构图一](images/Pasted-image-20240812174743.png)


# 架构图2：

![[images/Pasted-image-20240812174854.png]]
